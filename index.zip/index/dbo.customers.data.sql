﻿INSERT INTO [dbo].[customers] ([Id], [firstName], [lastName], [emailAddress], [phoneNumber], [password]) VALUES (NULL, N'meshari', N'matfri', N'cs.mesharetest@gmail.com', N'0555555555', N'102030')
INSERT INTO [dbo].[customers] ([Id], [firstName], [lastName], [emailAddress], [phoneNumber], [password]) VALUES (NULL, N'mga', N'asiri', N'mga@gmail.com', N'0555555555', N'12345')
INSERT INTO [dbo].[customers] ([Id], [firstName], [lastName], [emailAddress], [phoneNumber], [password]) VALUES (NULL, N'nawaf', N'mohammed', N'nawaf@gmail.com', N'0599999999', N'12345')
INSERT INTO [dbo].[customers] ([Id], [firstName], [lastName], [emailAddress], [phoneNumber], [password]) VALUES (NULL, N'saeed', N'asiri', N'saeedasiri10@gmail.com', N'+966580536002', N'12345')
