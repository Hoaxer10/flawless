﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Net;
using System.Net.Mail;

namespace index
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string con = ConfigurationManager.ConnectionStrings["ma"].ConnectionString;
            SqlConnection con1 = new SqlConnection(con);
            string sqlquery = "select emailAddress,password from customers where emailAddress = @emailAddress";
            SqlCommand cmd = new SqlCommand(sqlquery, con1);
            cmd.Parameters.AddWithValue("@emailAddress", TextBox1.Text);
            con1.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if(reader.Read())
            {
                string userName = reader["emailAddress"].ToString();
                string password = reader["password"].ToString();

                MailMessage message = new MailMessage("saeedtestasp@gmail.com", TextBox1.Text);
                message.Subject = "Your password";
                message.Body = string.Format("hello : <h1>{0}</h1> is your email id<br/> ypur password is <h1>{1}</h1>", userName, password);
                message.IsBodyHtml = true;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.EnableSsl = true;
                NetworkCredential ncc = new NetworkCredential();
                ncc.UserName = "saeedtestasp@gmail.com";
                ncc.Password = "11223344Ss";
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = ncc;
                smtp.Port = 587;
                smtp.Send(message);
                Label1.Text = "your password has been sent to " + TextBox1.Text;
                Label1.ForeColor = Color.Green;
                ClientScript.RegisterStartupScript(this.GetType(), "randomtext", "alertme()", true);

            }
            else
            {
                Label1.Text = TextBox1.Text + "- this email is not exist";
                Label1.ForeColor = Color.Red;


            }

        }
    }
}